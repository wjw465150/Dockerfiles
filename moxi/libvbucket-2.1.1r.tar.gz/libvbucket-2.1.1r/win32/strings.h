#ifndef STRINGS_H
#define STRINGS_H

#define strcasecmp(a,b) _stricmp(a,b)
#define strdup(a) _strdup(a)
#define snprintf _snprintf

#endif
