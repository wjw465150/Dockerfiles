/*
 * We don't have any config variables to set...
 */
#ifndef CONFIG_H
#define CONFIG_H

#endif
