#ifndef STDIN_CHECK_H
#define STDIN_CHECK_H

int stdin_check(void);

#endif
