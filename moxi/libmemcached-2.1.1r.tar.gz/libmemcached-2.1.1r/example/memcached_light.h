/* -*- Mode: C; tab-width: 2; c-basic-offset: 2; indent-tabs-mode: nil -*- */
#ifndef MEMCACHED_LIGHT_H
#define MEMCACHED_LIGHT_H

extern void initialize_interface_v0_handler(void);

#endif
